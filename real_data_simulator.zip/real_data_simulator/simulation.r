rm(list=ls())

code_path <- '/home/tiger/ConformalOPE/code/src'
files <- list.files(path = code_path, full.names = TRUE, include.dirs = TRUE)
for (file in files) {
    source(file)
}

library(foreach)
library(doParallel)

cl <- makeCluster(5)
registerDoParallel(cl)

trainprop <- 0.75
quantiles <- c(0.05, 0.95)
psfun <- Logistic
psparams <- NULL
outfun <- quantRF
outparams <- NULL
type <- "CQR"
side <- "two"
alpha <- 0.1
wthigh <- 20
wtlow <- 0.05
weighted <- TRUE

features = c('X1', 'X2')

Deta <- c(0,1,-1)

methods <- c('Sweight', 'BootSweight', 'Dweight', 'BootDweight')

one_call <- function(i) {
    df_train <- read.csv(paste('simulator_data/df_b_',i,'.csv',sep=''))
    X <- as.matrix(df_train[features])
    T <- df_train[['T']]
    Y <- df_train[['Y']]

    df_test <- read.csv(paste('simulator_data/df_e_',i,'.csv',sep=''))
    Xtest <- as.matrix(df_test[features])
    Ttest <- df_test[['T']]
    Ytest <- df_test[['Y']]

    ntest <- nrow(df_test)
    
    ret <- matrix(0, nrow=2, ncol=4)
    
    for (j in c(1:4))
    {
        print(j)

        method <- methods[j]

        B <- 1
        if (grepl('Boot', method)) 
        {
            B <- 100
        }

        out <- ConformalCI(X,Y,T,Deta,Xtest,method,B,
                           trainprop,psfun,psparams,outfun,outparams,
                           quantiles,type,side,weighted,alpha,wthigh,wtlow)

        if((B==1) & (method == "Sweight" | method == "Dweight"))
        {  
            #summary for single split
            ind <- (Ytest<unlist(out$rights))&(Ytest>=unlist(out$lefts))
            ret[1,j] <- mean(ind)
            ret[2,j] <- mean(out$Lens)
        } 
        else if((B>1) & (method == "BootSweight" | method == "BootDweight"))
        {
            #summary for multiple split
            ind <- NULL
            for(k in 1:ntest)
            {
                NInt <- length(out$lefts[k])
                flag <- unlist(lapply(seq(1:NInt), function(x) return((out$lefts[[k]][x]<=Ytest[k])&(Ytest[k]<out$rights[[k]][x]))))
                ind[k] <- (sum(flag)>0)
            }
            ret[1,j] <- mean(ind)
            ret[2,j] <- mean(out$Lens)
        }
    }
                                      
    return(ret)
}
                                      

rets <- foreach(i=1:20, .combine=cbind) %dopar% 
{
    ret <- one_call(i)
    return(ret)
}

#stop cluster
stopCluster(cl)

# save.image('RealDataSimulator.Rdata')

rets

final_rets <- matrix(0, 3, 4)
for (i in c(1:4)) {
    final_rets[,i] <- apply(rets[, seq(i, 80, by=4)], 1, median)
}
round(final_rets,3)


